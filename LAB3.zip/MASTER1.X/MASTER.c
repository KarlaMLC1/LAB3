
// Configuraci�n de los bits de configuraci�n para el PIC16F887
#pragma config  FOSC    = INTRC_NOCLKOUT   // Oscilador interno, sin salida de reloj
#pragma config  WDTE    = OFF              // Desactivar el Watchdog Timer
#pragma config  PWRTE   = OFF              // Desactivar el Power-up Timer
#pragma config  MCLRE   = OFF              // La funci�n del pin MCLR es entrada digital
#pragma config  CP      = OFF              // Desactivar la Protecci�n de C�digo
#pragma config  CPD     = OFF              // Desactivar la Protecci�n de Datos de C�digo
#pragma config  BOREN   = OFF              // Desactivar el Brown-out Reset
#pragma config  IESO    = OFF              // Desactivar el Switchover Interno/Externo
#pragma config  FCMEN   = OFF              // Desactivar el Monitor de Reloj Fail-Safe
#pragma config  LVP     = OFF              // Desactivar la Programaci�n de Bajo Voltaje

#pragma config  BOR4V   = BOR40V           // Brown-out Reset configurado a 4.0V
#pragma config  WRT     = OFF              // Desactivar la Protecci�n de Escritura en Memoria Flash

#include <stdint.h>
#include <stdio.h>  // Agregar esta l�nea para usar sprintf
#include <xc.h>
#include "LCD.h"
#include "SPIMASTER.h"                    // Incluir el archivo de encabezado para la comunicaci�n SPI Master
#define FLAG_SPI 0xFF
#define _XTAL_FREQ  8000000                // Definir la frecuencia del oscilador para la funci�n __delay_ms()
#define CONT 0xAA
//char Esclavo, EsclavoDos;
uint8_t pot1, pot2, contador;


void setup(void);

void main(void) {
    setup();                             // Llamar a la funci�n de configuraci�n para inicializar el PIC
    char lcd_buffer[17]; // Buffer para almacenar los datos a mostrar en la pantalla LCD

    while(1){
        PORTCbits.RC2 = 1;               // Establecer en bajo el pin Slave Select (SS) para habilitar el dispositivo esclavo
        PORTCbits.RC1 = 0;
        __delay_ms(1);                   // Retardo de un corto per�odo de tiempo (1 ms)

        spiWrite(CONT);              // Enviar un byte (FLAG_SPI) a trav�s de SPI al esclavo
        pot1 = spiRead();               // Leer el byte recibido desde el buffer SPI y almacenarlo en PORTD

        __delay_ms(1);                   // Retardo de un corto per�odo de tiempo (1 ms)
        PORTCbits.RC2 = 1;               // Establecer en alto el pin Slave Select (SS) para deshabilitar el dispositivo esclavo
        PORTCbits.RC1 = 0;               // Establecer en alto el pin Slave Select (SS) para deshabilitar el dispositivo esclavo
        __delay_ms(1);                   // Retardo de un corto per�odo de tiempo (1 ms)

        spiWrite(FLAG_SPI);              // Enviar un byte (FLAG_SPI) a trav�s de SPI al esclavo
        contador = spiRead();               // Leer el byte recibido desde el buffer SPI y almacenarlo en PORTD

        // segundo esclavo
        
        PORTCbits.RC1 = 1;               // Establecer en bajo el pin Slave Select (SS) para habilitar el dispositivo esclavo
        PORTCbits.RC2 = 0; 
        __delay_ms(1);                   // Retardo de un corto per�odo de tiempo (1 ms)

        spiWrite(FLAG_SPI);              // Enviar un byte (FLAG_SPI) a trav�s de SPI al esclavo
        pot2 = spiRead();               // Leer el byte recibido desde el buffer SPI y almacenarlo en PORTD

        __delay_ms(1);                   // Retardo de un corto per�odo de tiempo (1 ms)
        PORTCbits.RC1 = 1;    
        PORTCbits.RC2 = 1;
        
        // Limpieza y escritura de datos en la LCD
        Lcd_Clear();
        Lcd_Set_Cursor(1, 1);
        Lcd_Write_String("Pot1: Pot2: Cont:");
        
        // Convertir los valores num�ricos en cadenas y guardarlos en el buffer
        sprintf(lcd_buffer, "%3u.%1u", pot1 / 10, pot1 % 10); // Formato para mostrar un n�mero ENTERO
        Lcd_Set_Cursor(2, 1);
        Lcd_Write_String(lcd_buffer);
        
        sprintf(lcd_buffer, "%3u.%1u", pot2 / 10, pot2 % 10); // Formato para mostrar un n�mero decimal
        Lcd_Set_Cursor(2, 7);
        Lcd_Write_String(lcd_buffer);

        sprintf(lcd_buffer, "%3u", contador / 10, contador % 10); // Formato para mostrar un n�mero decimal
        Lcd_Write_String(lcd_buffer);
        

    }
    return;
}

void setup(void){
    
    ANSEL = 0;                           // Configurar todos los pines como entradas/salidas digitales
    ANSELH = 0;
    
    TRISCbits.TRISC2 = 0;               // Configurar el pin RC2 como salida (para SS)
    TRISCbits.TRISC1 = 0;               // Configurar el pin RC2 como salida (para SS)
    TRISB = 0;                          // Configurar todos los pines del Puerto B como salidas
    TRISD = 0;                          // Configurar todos los pines del Puerto D como salidas
    
    PORTB = 0;                          // Inicializar el valor del Puerto B en 0
    PORTD = 0;                          // Inicializar el valor del Puerto D en 0
    PORTCbits.RC2 = 1;                  // Establecer en alto el pin Slave Select (SS) inicialmente
    PORTCbits.RC1 = 1;                  // Establecer en alto el pin Slave Select (SS) inicialmente
    Lcd_Init();
    //adc_init(0);
    
    spiInit(SPI_MASTER_OSC_DIV4, SPI_DATA_SAMPLE_MIDDLE, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);
}

