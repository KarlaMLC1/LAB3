
// Configuraci�n de los bits de configuraci�n para el PIC16F887
#pragma config  FOSC    = INTRC_NOCLKOUT   // Oscilador interno, sin salida de reloj
#pragma config  WDTE    = OFF              // Desactivar el Watchdog Timer
#pragma config  PWRTE   = OFF              // Desactivar el Power-up Timer
#pragma config  MCLRE   = OFF              // La funci�n del pin MCLR es entrada digital
#pragma config  CP      = OFF              // Desactivar la Protecci�n de C�digo
#pragma config  CPD     = OFF              // Desactivar la Protecci�n de Datos de C�digo
#pragma config  BOREN   = OFF              // Desactivar el Brown-out Reset
#pragma config  IESO    = OFF              // Desactivar el Switchover Interno/Externo
#pragma config  FCMEN   = OFF              // Desactivar el Monitor de Reloj Fail-Safe
#pragma config  LVP     = OFF              // Desactivar la Programaci�n de Bajo Voltaje

#pragma config  BOR4V   = BOR40V           // Brown-out Reset configurado a 4.0V
#pragma config  WRT     = OFF              // Desactivar la Protecci�n de Escritura en Memoria Flash

#include <stdint.h>
#include <xc.h>
#include "SPISLAVE.h"                      // Incluir el archivo de encabezado para la comunicaci�n SPI Slave
#include "ADC.h"                          // Incluir el archivo de encabezado para la lectura del ADC
#define CONT 0xAA
#define _XTAL_FREQ  8000000               // Definir la frecuencia del oscilador para la funci�n __delay_ms()

uint8_t val, pot1;                             
uint8_t counter = 0; // Contador para almacenar el valor del puerto D
void setup(void);

void __interrupt() isr(void){
    
     if (INTCONbits.RBIF) { // Verificar si la interrupci�n es del cambio de estado del puerto B (RBIF)
        // Peque�o retardo para evitar el rebote del bot�n
        __delay_ms(10);

       
        // Borrar la bandera de interrupci�n RBIF
        INTCONbits.RBIF = 0;
    }

     
     
    else if(PIR1bits.SSPIF == 1){
        val = spiRead();
        
        if (RB0 == 0) { // Verificar si se presion� el bot�n RB0 (se asume que est� conectado a tierra)
            counter++; // Incrementar el contador si se presion� el bot�n RB0
            __delay_ms(1);
        }
        if (RB1 == 0) { // Verificar si se presion� el bot�n RB1 (se asume que est� conectado a tierra)
            counter--; // Decrementar el contador si se presion� el bot�n RB1
           __delay_ms(1);
        }
         
         if(val==CONT){
             
        spiWrite(counter);  
        }
        else {
           spiWrite(pot1);  
        }// Cuando se recibe un byte por SPI, se env�a el contenido de PORTD al maestro
        //spiWrite(counter);


        PIR1bits.SSPIF = 0;
    }
}

void main(void) {
    setup();                             // Llamar a la funci�n de configuraci�n para inicializar el PIC
    while(1){
        pot1 = ADC_READ();              // Leer el valor del ADC y almacenarlo en PORTD
       // PORTD=counter;
    }
    return;
}

void setup(void){
    OSCILLATOR(1);                       // Configurar el oscilador a 8 MHz

    ANSEL =  0b00110000;                 // Configurar el pin AN5 como entrada anal�gica
    ANSELH = 0;

    TRISB = 0b00000011;  // RB0 y RB1 como entradas, el resto como salidas
    PORTB = 0;           // Inicializar el valor del Puerto B en 0
    TRISD = 0x00; // Todos los pines del puerto D como salidas (LEDs)
    PORTD = 0x00; // Inicializar el valor del puerto D en 0
          

    // Configuraci�n del ADC
    ADC_INIT(5);                         // Inicializar el ADC para usar el canal 5

    INTCONbits.GIE = 1;                  // Habilitar las interrupciones globales
    INTCONbits.PEIE = 1;                 // Habilitar las interrupciones perif�ricas
    PIR1bits.SSPIF = 0;                  // Borrar la bandera de interrupci�n del MSSP (SPI)
    PIE1bits.SSPIE = 1;                  // Habilitar la interrupci�n del MSSP (SPI)
    PIR1bits.RCIF = 0;     // Borrar la bandera de interrupci�n de recepci�n (se recomienda hacerlo antes de habilitar la interrupci�n)
    PIE1bits.RCIE = 1;     // Habilitar la interrupci�n de recepci�n de datos
   
    INTCONbits.RBIE = 1; // Habilita las interrupciones del cambio de estado del puerto B (RBIF)
    OPTION_REGbits.nRBPU = 0;
    //TRISB = 0b00000011; // RB0 y RB1 como entradas (botones), los dem�s como salidas
    WPUB = 0b00000011;  // Habilitar resistencias pull-up para RB0 y RB1
    
    TRISAbits.TRISA5 = 1;                // Configurar el pin RA5 como entrada para Slave Select (SS)

    spiInit(SPI_SLAVE_SS_EN, SPI_DATA_SAMPLE_MIDDLE, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE); // Inicializar la comunicaci�n SPI como esclavo
 }

